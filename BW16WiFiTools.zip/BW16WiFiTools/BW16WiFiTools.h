#ifndef BW16WIFITOOLS_H
#define BW16WIFITOOLS_H

#include <Arduino.h>
#include "WiFi.h"

class BW16WiFiTools {
public:
    BW16WiFiTools();
    void begin();
    void scanNetworks(bool displayResults = true);
    void startDeauth(const String& targetSSID, uint8_t channel, uint32_t durationMs);
    void stopDeauth();
    void loop();

    void setDisplayCallback(void (*callback)(const String&));
    void setButtonPins(uint8_t left, uint8_t middle, uint8_t right);

private:
    void (*displayCallback)(const String&) = nullptr;
    uint8_t buttonLeft, buttonMiddle, buttonRight;
    bool deauthActive = false;
    unsigned long deauthEndTime = 0;
    String targetSSID;
    uint8_t targetChannel;

    void performDeauth();
};

#endif