#include "BW16WiFiTools.h"

BW16WiFiTools::BW16WiFiTools() {}

void BW16WiFiTools::begin() {
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();
    delay(100);
}

void BW16WiFiTools::setDisplayCallback(void (*callback)(const String&)) {
    displayCallback = callback;
}

void BW16WiFiTools::setButtonPins(uint8_t left, uint8_t middle, uint8_t right) {
    buttonLeft = left;
    buttonMiddle = middle;
    buttonRight = right;
    pinMode(buttonLeft, INPUT_PULLUP);
    pinMode(buttonMiddle, INPUT_PULLUP);
    pinMode(buttonRight, INPUT_PULLUP);
}

void BW16WiFiTools::scanNetworks(bool displayResults) {
    int n = WiFi.scanNetworks();
    if (displayCallback && displayResults) {
        for (int i = 0; i < n; ++i) {
            String info = "SSID: " + WiFi.SSID(i) + " | RSSI: " + String(WiFi.RSSI(i)) +
                          " | CH: " + String(WiFi.channel(i)) + " | ENC: " + String(WiFi.encryptionType(i));
            displayCallback(info);
        }
    }
    WiFi.scanDelete();
}

void BW16WiFiTools::startDeauth(const String& ssid, uint8_t channel, uint32_t durationMs) {
    targetSSID = ssid;
    targetChannel = channel;
    deauthEndTime = millis() + durationMs;
    deauthActive = true;
    if (displayCallback) displayCallback("Deauth ATTACK started on: " + ssid);
}

void BW16WiFiTools::stopDeauth() {
    deauthActive = false;
    if (displayCallback) displayCallback("Deauth ATTACK stopped.");
}

void BW16WiFiTools::loop() {
    if (deauthActive) {
        if (millis() > deauthEndTime) {
            stopDeauth();
            return;
        }
        performDeauth();
    }
}

void BW16WiFiTools::performDeauth() {
    // Simulación de ataque deautenticación (esto debe integrarse con hardware real y lib específica)
    if (displayCallback) displayCallback("Sending deauth packets on CH " + String(targetChannel));
    delay(100); // Simula envíos repetidos
}