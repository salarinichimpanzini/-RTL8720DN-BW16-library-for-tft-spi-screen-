#ifndef BW16UI_H
#define BW16UI_H

#include <Arduino.h>
#include <SPI.h>
#include <SdFat.h>

// RGB565 color definitions
#define UI_BLACK   0x0000
#define UI_WHITE   0xFFFF
#define UI_RED     0xF800
#define UI_GREEN   0x07E0
#define UI_BLUE    0x001F
#define UI_YELLOW  0xFFE0
#define UI_CYAN    0x07FF
#define UI_MAGENTA 0xF81F

class BW16UI {
public:
    BW16UI(uint8_t cs, uint8_t dc, uint8_t rst,
           uint8_t mosi, uint8_t sck, uint8_t miso,
           uint8_t touchCS, uint8_t touchIRQ,
           uint8_t sdCS);

    void begin();
    void clear(uint16_t color = UI_BLACK);
    void drawPixel(int16_t x, int16_t y, uint16_t color);
    void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color);
    void drawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
    void fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
    void drawCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color);
    void fillCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color);

    void setCursor(int16_t x, int16_t y);
    void setTextColor(uint16_t color);
    void setTextSize(uint8_t size);
    void print(const char* text);

    bool touchPressed();
    void getTouch(int16_t &x, int16_t &y);

    bool loadBitmap(const char* path, int16_t x, int16_t y);

    void showMenu(const String items[], uint8_t itemCount, uint8_t selected);

private:
    uint8_t _cs, _dc, _rst, _mosi, _sck, _miso, _touchCS, _touchIRQ, _sdCS;
    int16_t _cursorX, _cursorY;
    uint16_t _textColor;
    uint8_t _textSize;
    SdFat _sd;

    void spiInit();
    void sendCommand(uint8_t cmd);
    void sendData(uint8_t data);
    bool readTouchRaw(int16_t &x, int16_t &y);
};

#endif