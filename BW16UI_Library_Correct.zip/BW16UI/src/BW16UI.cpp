#include "BW16UI.h"

// Undefine conflicting macros
#ifdef max
#undef max
#endif
#ifdef min
#undef min
#endif

BW16UI::BW16UI(uint8_t cs, uint8_t dc, uint8_t rst,
               uint8_t mosi, uint8_t sck, uint8_t miso,
               uint8_t touchCS, uint8_t touchIRQ,
               uint8_t sdCS)
: _cs(cs), _dc(dc), _rst(rst),
  _mosi(mosi), _sck(sck), _miso(miso),
  _touchCS(touchCS), _touchIRQ(touchIRQ), _sdCS(sdCS),
  _cursorX(0), _cursorY(0), _textColor(UI_WHITE), _textSize(1)
{}

void BW16UI::begin() {
    pinMode(_cs, OUTPUT); pinMode(_dc, OUTPUT); pinMode(_rst, OUTPUT);
    digitalWrite(_rst, LOW); delay(50); digitalWrite(_rst, HIGH); delay(150);
    spiInit();
    _sd.begin(_sdCS, SD_SCK_MHZ(25));

    clear();
}

void BW16UI::spiInit() {
    SPI.begin(_sck, _miso, _mosi);
    SPI.setFrequency(40000000);
}

void BW16UI::sendCommand(uint8_t cmd) {
    digitalWrite(_dc, LOW); digitalWrite(_cs, LOW);
    SPI.transfer(cmd);
    digitalWrite(_cs, HIGH);
}

void BW16UI::sendData(uint8_t data) {
    digitalWrite(_dc, HIGH); digitalWrite(_cs, LOW);
    SPI.transfer(data);
    digitalWrite(_cs, HIGH);
}

void BW16UI::clear(uint16_t color) {
    fillRect(0,0,240,320,color);
}

void BW16UI::drawPixel(int16_t x, int16_t y, uint16_t color) {
    sendCommand(0x2A); sendData(x >> 8); sendData(x & 0xFF);
    sendCommand(0x2B); sendData(y >> 8); sendData(y & 0xFF);
    sendCommand(0x2C);
    sendData(color >> 8); sendData(color & 0xFF);
}

void BW16UI::drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color) {
    // Bresenham
    int dx = abs(x1 - x0), sx = x0<x1?1:-1;
    int dy = -abs(y1 - y0), sy = y0<y1?1:-1;
    int err = dx+dy, e2;
    while(true) {
        drawPixel(x0,y0,color);
        if(x0==x1 && y0==y1) break;
        e2 = 2*err; if(e2>=dy){ err+=dy; x0+=sx;} if(e2<=dx){ err+=dx; y0+=sy;}
    }
}

void BW16UI::drawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) {
    drawLine(x,y,x+w-1,y,color);
    drawLine(x,y+h-1,x+w-1,y+h-1,color);
    drawLine(x,y,x,y+h-1,color);
    drawLine(x+w-1,y,x+w-1,y+h-1,color);
}

void BW16UI::fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) {
    for(int16_t i=x;i<x+w;i++) drawLine(i,y,i,y+h-1,color);
}

void BW16UI::drawCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color) {
    int f = 1 - r, ddF_x = 1, ddF_y = -2*r;
    int x = 0, y = r;
    drawPixel(x0, y0+r, color);
    drawPixel(x0, y0-r, color);
    drawPixel(x0+r, y0, color);
    drawPixel(x0-r, y0, color);
    while(x<y) {
        if(f>=0){ y--; ddF_y+=2; f+=ddF_y;} x++; ddF_x+=2; f+=ddF_x;
        drawPixel(x0 + x, y0 + y, color); drawPixel(x0 - x, y0 + y, color);
        drawPixel(x0 + x, y0 - y, color); drawPixel(x0 - x, y0 - y, color);
        drawPixel(x0 + y, y0 + x, color); drawPixel(x0 - y, y0 + x, color);
        drawPixel(x0 + y, y0 - x, color); drawPixel(x0 - y, y0 - x, color);
    }
}

void BW16UI::fillCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color) {
    for(int16_t y=-r;y<=r;y++)
        for(int16_t x=-r;x<=r;x++)
            if(x*x+y*y<=r*r) drawPixel(x0+x,y0+y,color);
}

void BW16UI::setCursor(int16_t x, int16_t y) {
    _cursorX = x; _cursorY = y;
}

void BW16UI::setTextColor(uint16_t color) {
    _textColor = color;
}

void BW16UI::setTextSize(uint8_t size) {
    _textSize = size;
}

void BW16UI::print(const char* text) {
    // Placeholder: render text using bitmap font from Fonts/
}

bool BW16UI::touchPressed() {
    return digitalRead(_touchIRQ) == LOW;
}

void BW16UI::getTouch(int16_t &x, int16_t &y) {
    readTouchRaw(x,y);
}

bool BW16UI::readTouchRaw(int16_t &x, int16_t &y) {
    // Placeholder: XPT2046 or similar
    return false;
}

bool BW16UI::loadBitmap(const char* path, int16_t x, int16_t y) {
    File f = _sd.open(path);
    if(!f) return false;
    // BMP parsing
    f.close();
    return true;
}

void BW16UI::showMenu(const String items[], uint8_t itemCount, uint8_t selected) {
    clear(UI_BLUE);
    for(uint8_t i=0;i<itemCount;i++) {
        uint16_t by = 40 + i*40;
        fillRect(20, by, 200, 30, (i==selected)?UI_YELLOW:UI_WHITE);
        setCursor(30, by+8);
        setTextColor(UI_BLACK);
        print(items[i].c_str());
    }
}